setwd("C:\\Users\\it24101240\\Desktop\\IT24101240-Lab 06")
getwd()
#1
#ii)
pbinom(46, 50, 0.85, lower.tail = FALSE)

#2
#	i) Number of customer calls received in an hour
# ii) Poisson distribution
#iii
dpois(15, 12)
