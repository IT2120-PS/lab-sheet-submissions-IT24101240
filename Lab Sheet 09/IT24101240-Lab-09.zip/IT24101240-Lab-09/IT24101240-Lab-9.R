setwd("C:\\Users\\W.A Maleesha\\Documents\\Year 2 Semester 1\\PS\\Labsheet\\IT24101240-Lab-09")

#Exercise
# 1. generate a random sample of size 25 for the baking time.
bake <- rnorm(25, mean = 45, sd = 2)
bake

# 2. Test whether the average baking time is less than 46 minutes at a 5% level of
# significance
res <- t.test(bake, mu = 46, alternative = "less")


res

# Extract specific values
res$statistic  
res$p.value     
res$conf.int 
