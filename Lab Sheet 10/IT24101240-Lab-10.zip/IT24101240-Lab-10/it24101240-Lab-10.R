setwd("C:\\Users\\it24101240\\Desktop\\IT24101240-Lab-10")
data <- read.csv("Data.csv", row.names = 1)


# i)
snack_counts <- c(120, 95, 85, 100)
expected_prob <- c(0.25, 0.25, 0.25, 0.25)

# ii)
chisq.test(x=snack_counts,, p=expected_prob)

chisq <- chisq.test(data)
chisq

# iii)
# Display the test result
#If the p-value < 0.05, reject the null hypothesis-There is a significant difference in snack preferences.
#If the p-value ≥ 0.05, do not reject the null hypothesis-No significant difference; choices are equally likely.
# p value > 0.05 so No significant difference; choices are equally likely