setwd("C:\\Users\\it24101240\\Desktop\\IT24101240-Lab-10")

observe <- c(55,62,43,46,50)
prob <- c(.2,.2,.2,.2,.2)

chisq.test(x=observe,, p=prob)


file_path <- "https://www.sthda.com/sthda/RDoc/data/housetasks.txt"

housetasks <- read.delim(file_path, row.names = 1)
housetasks

chisq <- chisq.test(housetasks)
chisq

# p < 0.05
# reject the null value
