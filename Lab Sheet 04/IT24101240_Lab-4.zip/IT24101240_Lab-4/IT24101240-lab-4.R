setwd("C:\\Users\\it24101240\\Desktop\\IT24101240_Lab-4")

#1
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
fix(branch_data)
attach(branch_data)

summary(branch_data)
any(is.na(branch_data))  


#3

boxplot(branch_data$Sales_X1, main = "Boxplot of Sales", ylab = "Sales")


#4

summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)
    

#5

get_outliers <- function(x) {
  q1 <- quantile(x)[2]
  q3 <- quantile(x)[4]
  iqr <- q3 - q1
  lb <- q1 - 1.5 * iqr
  ub <- q3 + 1.5 * iqr
  return(x[x < lb | x > ub])
}

get_outliers(branch_data$Years_X3)

             

