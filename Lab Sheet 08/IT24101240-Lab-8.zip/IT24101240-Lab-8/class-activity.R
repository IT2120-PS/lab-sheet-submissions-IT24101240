setwd("C:\\Users\\it24101240\\Desktop\\IT24101240-Lab-8")
data<-read.table("Data - Lab 8.txt",header = TRUE)
fix(data)
attach(data)
popmn<-mean(Nicotine)
popmn
popvar<- var(Nicotine)
popvar

samples <- c()
n <- c()

for (i in 1:30) {
  s <- sample(Nicotine, 5, replace = TRUE)
  samples <- cbind(samples, s)
  n <- c(n,paste("s", i))
}
n

colnames(samples) = n

s.means <- apply(samples, 2, mean)
s.means
s.vars <- apply(samples, 2, var)
s.vars

samplemean<-mean(s.means)
samplemean
samplevars<-var(s.means)
samplevars

popmn
samplemean

truevar = popvar/5
truevar
samplevars

